x="annoying"
print(len(x))
glass_of_water=0
print("I drank",glass_of_water,"glasses of water today")
print("\n")
print("\n")
men=12
print(men,"men stepped on the moon ")
my_reason_for_coding="mom"
print("my",my_reason_for_coding,"is the reason for coding")
x=98
y=45.67
z="Python"
print(type(x))
print(type(y))
print(type(z))
print("\n")
x=y=z=100
print(x,y,z)
print("\n")
x="Kyler "
y="Tsui"
print(x+y)
print("\n")
x,y,z=1,2,3
print(x,y,z)


















