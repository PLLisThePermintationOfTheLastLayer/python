#escape cahracter
#single quate
text='It\'s tuesday today'
print(text)
text="Hi\tBYe"
print(text)
text="hi,                 \b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\bbye"
print(text)
#PYTHON OPERATORS
#Arithmetic:(+,-,*,/,%,**,//)
x=9
y=4
print(x+y)
print(x-y)
print(x*y)
print(x/y)
print(x%y)
print(x**y)
print(x//y)
print('\n')
#assignment operators:(=,+=,-=,*=,/=,**=,//=,&=,>>=,<<=)
x=7
x+=2
print(x)
x=7
x-=2
print(x)
x=7
x*=2
print(x)
x=7
x/=2
print(x)
x=7
x**=2
print(x)
x=7
x//=2
print(x)
x=7
x&=2
print(x)
x=7
x<<=2
print(x)
x=7
x>>=2
print(x)
print('\n')
#comparrison operators:(==,>=,<=,!=,<,>)
x=9
y=6
print(x==y)
print(x!=y)
print(x>y)
print(x<y)
print(x<=y)
print(x>=y)
print('\n')
#logical Operator(and,or,not)
a=10
print(a>4 and a>11)
print(a>4 or a>11)
print(not(a>4 and a>11))
print('\n')
#identity operators(is,is not)
x=["apple","kiwi"]
y=["apple","kiwi","orange"]
z=x
print(x is z)
print(x is y)
print(x is not z)
print(x is not y)
print(not(not(not(not(not(not(not(not(not(not(a < -9876345 or a > -2347962)))))))))))
#membership:(in,not in)
x=["apple","kiwi"]
print("kiwi" in x)
print("pear" in x)
print("kiwi" in not x)













