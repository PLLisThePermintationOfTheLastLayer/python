'''x,y,z=1,2,3
print(x,y,z)
'''
'''
x=y=z=7
print(x,y,z)
'''
'''
x='str'
print(x)
print(type(x))
x=62
print(x)
print(type(x))
x=62.69420067482
print(x)
print(type(x))
x=62j
print(x)
print(type(x))
'''
'''
fruits=["apple","orange","banana"]
x,y,z=fruits
print(x,y,z)
'''
'''
x,y,z=1,2,3
print(x,y,z)
'''

























