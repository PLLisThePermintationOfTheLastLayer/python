x="extraordinary"
print(x[5:13])
x="pneumonia"
print(x[4:9])
#slicing negative index
c="Hello world "
print(c[-6:-1])
#back to practice
x="Programming"
print(x[-11:-3])
y="establishment"
print(y[-4:-1])
z="Pneumonoultramicroscopicsilicovolcanoconiosis"
print(z[-32:-21])
a="hello word"
print(a.upper())`
b="HELLO WORLD"
print(b.lower())
#strip() used t remove whitw spaces
text="Hard things are hard to get"
print(text.strip())
string ="Milo"
print(string.replace("M","k"))
#Split() is used to split up a single string into to different string
x="Python, better than c++"
y=x.split(',')
print(y)
#format() is used to insert numbers into the strings
age=45
text="Yesterday, a aman named John came to the hospital who was {} years old"
print(text.format(age))
e="each"
text="  I bought 3 pieces of cake for 45.98 dollars {}"
print(text.format(e),"\n",text.strip())
x="hat"
print(x.replace("h","M"))
y="Python ,>, c++"
print(y.split(","))
#capitilize:
text="Today is friday."
x=text.capitalize()
print(x)
y="25 is a number"
x=y.capitalize()
print(x)












