#sets:
#Used to store multiple items in a single variable
#sets are ubordered,unchangeable,unindexed
myset={1,2,3,4}
print(myset)
myset1={'apple',"kiwi",2,5,'apple',True}
print(myset1)
print(len(myset1))
print(type(myset1))
#set constructor:
myset=set(('apple',67.9,False,56,7j))
print(myset)
#Acsess set items:
set1={'a','b','c','d'}
for x in set1:
    print(x)
#check sets:
print('c' in set1)
#add set items()
set_1={'kiwi','apple','orange'}
set_1.add('pear')
print(set_1)
#update()
set_2={'kiwi','apple','orange'}
set_3={'green','red','yellow'}
set_2.update(set_3)
print(set_2)
#add and iterables:(list,tuple,set,dictionary)
set_2={'kiwi','apple','Lychee'}
mylist={'orange','cherry'}
set_2.update(mylist)
print(set_2)
set_2={'kiwi','apple','Lychee'}
set_2.remove('kiwi')
print(set_2)
set_2={'kiwi','apple','Lychee'}
set_2.discard('kiwi')
print(set_2)
set_2={'kiwi','apple','Lychee'}
set_2.clear()
print(set_2)
#loop sets
myset={1,2,3,4,'a','b',True}
for x in myset:
    print(x)
    print(myset)
#join set
#union
set1={1,2,3}
set2={'kiwi','apple','Lychee'}
set3=set1.union(set2)
print(set3)
#update
et1={1,2,3}
set2={'kiwi','apple','Lychee'}
set1.update(set2)
print(set_1)
#intersection_update():
set1={1,2,3,'kiwi'}
set2={'kiwi','apple','orange'}
set1.intersection_update(set_2)
#symmetric_differnece_update():
set1={1,2,3,'kiwi'}
set2={'kiwi','apple','orange'}
set1.symmetric_difference_update(set_2)




print('\n')
print('\n')
print('\n')
print('\n')
print('\n')
print('\n')
print('\n')
print('\n')













#practice
myset={1,2,3,4,'a','b',True}
print(myset)
setc=set((1,2,3,4,'a','b',True))
print(setc)
myset={1,2,3,4,'a','b',True}
for x in myset:
    print(x)
set_1={'kiwi','apple','Lychee'}
set2={'orange','banana'}
set_1.update(set2)
print(set_1)
set_1={'kiwi','apple','Lychee'}
set_1.pop()
print(set_1)
set_1={'kiwi','apple','Lychee'}
set_1.add('orange')
print(set_1)






























