#list:(Used to store multiple items in 1 variable)
my_list=["Monday","Tuesday","Wendsday"]
print(my_list)
my_list=["Monday","Tuesday","Wendsday","Monday"]
print(my_list)
#length
my_list=["Monday","Tuesday","Wendsday","wensday","Monday"]
print(len(my_list))
#type
my_list=["Monday","Tuesday","Wendsday","wensday","Monday"]
print(type(my_list))
list1=[1,2,3,4,5,6,7,8,9,"hello",True]
print(list1)
print(type(list1))
#List()constructor
mylist=list(("apple","orange"))
print(mylist)
#Acsess item
list_1=["apple","kwiw","orange","melon","cherry"]
print(list_1[2:5])
list_1=["apple","kwiw","orange","melon","cherry"]
print(list_1[2:])
list_1=["apple","kwiw","orange","melon","cherry"]
print(list_1[:5])
list_1=["apple","kwiw","orange","melon","cherry"]
print(list_1[-3:])
list_1=["apple","kwiw","orange","melon","cherry"]
print(len(list_1))
print(type(list_1))
list12345=["hi","bye","never met","never existed","gone"]
print(list12345[1])
print(list12345[-2])
#change items:
list_2=["apple","orange","banana"]
list_2[2]="pear"
print(list_2)
list_2=["apple","orange","banana"]
list_2[1:3]=["watermelon","cherry"]
print(list_2)
#add items
#append() method:
list2=["apple","orange","banana"]
list2.append("pear")
print(list2)
#insert()
list2=["apple","orange","banana"]
list2.insert(2,"cherry")
print(list2)






