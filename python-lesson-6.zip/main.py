#extended list
fruits=["apple","orange","banana"]
veg=["Brocoli","carrots","potato"]
fruits.extend(veg)
print(fruits)
#iterable:tuples,sets,dictionaries
fruits=["apple","orange","banana"]
veg=("Brocoli","carrots","potato")#tuple
fruits.extend(veg)
print(fruits)
print("\n")
#practice
num=[1,2,3,4]
num2=[5,6,7,8]
num.extend(num2)
print(num)
print("\n")
#remove list
x=[1,2,3,4]
x.remove(2)
print(x)
fruits=["apple","orange","banana"]
fruits.remove("banana")
print(fruits)
x=[1,2,3,4]
x.clear()
print(x)
'''
fruits=["apple","orange","banana"]
del fruits
print(fruits)
'''
print("\n")
#practice
f=["apple","orange","Raymond","banana","Kiwi"]
f.clear()
print(f)
#loop lits
a=[1,2,3,4,5,6,7,8,9,0]
for x in a:
    print(x)
    print("\n")
a=[1,2,3,4,5,6,7,8,9,0]
for i in range(len(a)):
    print(a[i])
#while loops
fruits=["apple","orange","Raymond","banana","Kiwi"]
i=0
while i < len(fruits):
    print(fruits[i])
    i=i+1
#short hand fpr loop
f=["Apple","orange","banana"]
[print(x) for x in f]
a=[1,2,3,4,5,6,7,8,9]
for x in a:
    print(x)
    print("\n")
    #practice
a=["a","b"]
i=0
while i<len(a):
    print(a[i])
    i=i+1
a=[1,2,3,4,5,6,7,8,9,10]
i=0
while i <len(a):
    print(a[i],"\n")
    i=i+1
a=[1,2,3,4,5,6,7,8,9,10]
[print(x) for x in a]















