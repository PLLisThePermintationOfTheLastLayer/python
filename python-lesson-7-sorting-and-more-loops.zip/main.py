#loop comprehention:
fruits=["apple","kiwi","orange"]
lis2t=[]
for x in fruits:
    if "e" in x:
        lis2t.append(x)
print(lis2t)
fruits=["apple","kiwi","orange"]
lis2t=[x for x in fruits if 'e' in x]
print(lis2t)
print(lis2t)
fruits=["apple","kiwi","orange"]
lis2t=[x for x in fruits if x!="apple"]
print(lis2t)
newlist=[x for x in range(10)]
print(newlist)
newlist=[x for x in range(10) if x <= 10]
print(newlist)
fruits=["apple","kiwi","orange"]
lis2t=[x.upper() for x in fruits]
print(lis2t)
print('\n')
#sort list
fruits=["apple","kiwi","orange"]
fruits.sort()
print(fruits)
num=[5,6,4,7,2,1,8,0,9]
num.sort()
print(num)
#desending
fruits=["apple","kiwi","orange"]
fruits.sort(reverse=True)
print(fruits)
liste=["Umberalla",'conditioner',"parrot"]
liste.reverse()
print(liste)

#copy method
list3=["Umberalla",'conditioner',"parrot"]
list4=list3.copy()
print(list4)
#list method:
list3=["Umberalla",'conditioner',"parrot"]
newlist=list(list3)
print(newlist)



#practice
print('\n')
print('\n')
print('\n')
names=['Kyler','Brian','Raymond']
lista=[]
for x in names:
    if 'a' in x:
        lista.append(x)
print(lista)

liste=[x for x in range(21)]
print(liste)
names=['Kyler','Brian','Raymond']
names.sort()
print(names)
num=[1,3,2,4,5,7,8,0,2,3,4,6,67,67,6,4,23,40]
num.sort(reverse=True)
print(num)
num=[1,3,2,4,5,7,8,0,2,3,4,6,67,67,6,4,23,]
num.reverse()
print(num)







































