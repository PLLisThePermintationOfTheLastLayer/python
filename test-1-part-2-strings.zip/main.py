x="string"
print(x)
print(type(x))
word="amusement"
print(len(word))
print(word[5:8])
for x in word:
    print(x)
x="Today is monday"
print("monday" in x)
print("\n")
print("\n")
x="weewwewewwewew"
print(x.upper())
print(x.lower ())