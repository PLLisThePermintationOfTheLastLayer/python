#python bool
print(78>56)
print(56==56)
print(12<98)
print(8==6)
a=88
b=66
if b>a:
    print("A is greater than b")
else:
    print("b is greater than a")
    #bool() gives u true or False
    print(bool("Kyler"))
    print(bool(88))
    print(bool(False))
    print(bool())
    print(bool(0))
    print(bool(None))
    print(bool(""))
    x="hello"
    y=90
    print(bool(x))
    print(bool(y))
x=1
y=12
if x<y:
    print("You are right")
else:
    print("Wrong")
    
    
    
    
    
x=1
print(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool(bool))))))))))))))))))))))))))))
print(bool(x))
x="   s s csdcncd jcsdubsddc  dc sdcd 9sdc ,hccuhcn 0cc- sd  j0cciscashi9cdhd   9e hweuhcgdubwdwe i"
print(x.strip())
print(x.split(","))
x="cython > C++"
print(x.replace("c","P"))
    
    
    
    
    
