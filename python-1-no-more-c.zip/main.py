#python comment
#created by gurido van russum in 1991
#uses:
#1-Web development
#2-Software development
#3-Math
#4-Python Sytanx
print("python sytanx")
#Pyton indendtation
if 5>3:
    print("Five is greater than 5")
#Python variables
x=7
y=6
print(x,y)
#This is single comment
print("comment")
#multiline comments:
#New comment
'''
This is a new multiline comment
'''
print("no comment here")
name="Kyler"
age=3
print(name)
print("your age:",age)
#Yesterday came a patient named Burak. His age was 56. He was diagnosed with Covid.He is admitted in room no. 13. He crashed his car in the parking area.
#He works as a  manager in a bank.
pname="burack"
pAge=56
d="Covid-19"
room="room number",13
car="He crashed his car"
work="HE is the manager of a bank"
print("name:",pname)
print("age:",pAge)
print("Virus:",d)
print("Room:",room)
print(car)
print("work:",work)
print(type(name))
print(type(age))
a=1
A="\nKyler"
print(a,A)
#legal
my_var=1
my_var=2
MYVAY=3
#illlrgal
'''
2myvar
my-var
my var
'''
#Camel case:each word,exapt the first starts with a capital
firstName="Kyler"
#Pascal case: all caps or all words starts with a capital
FIRSTNAME="Kyler"
#snake case: each word is seperated with underscore
first_name="Kyler"




