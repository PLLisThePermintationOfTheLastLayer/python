#join list
list1=[1,2,3]
list2=["a","b","c"]
list3=list1+list2
print(list3)
print(list1+list2)
#appened()
list1=[1,2,3]
list2=["a","b","c"]
for x in list2:
    list1.append(x)
print(list1)
#extend()
list1=[1,2,3]
list2=["a","b","c"]
list1.extend(list2)
print(list1)
#tuples
#used to store multiple items in a variable
#tuples are ordered but unchangeable
#used round brackets
#create a tuple:
tuple1=("apple","Lychee",1,43.34,63j,False)
print(tuple1)
print(type(tuple1))
#tuple cunstructer
tuple1=tuple(("apple","Lychee",1,43.34,63j,False,1))
print(tuple1)
tuple1=tuple(("apple","Lychee",1,43.34,63j,False,1))
print(tuple1[2])
print(tuple1[1:3])
tuple2=("pear",7898.4,"kiwi",True,"pear",1)
print(tuple2[-4:-1])
thistuple=("Lychee is a fruit")
if "1234" in thistuple:
    print("yes")
else:
    print('no')


print('\n')
print('\n')


















#practice
list1=[1,2,3]
list2=["a","b","c"]
print(list1+list2)
list1=[1,2,3]
list2=["a","b","c"]
for x in list1:
    list1.append(list2)
print(list1)
list1=[1,2,3]
list2=["a","b","c"]
list1.extend(list2)
print(list1)
tuple1=tuple((1,2,'hi','bye',12))
print(len(tuple1))




























tuple1=("coding class is ")
if "coding"in tuple1:
    print(yes)





























