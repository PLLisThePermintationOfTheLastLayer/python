#Change tuples
tuple1=('appple','kiwi','pear')
x=list(tuple1)
x[1]='cherry'
x=tuple(x)
print(x)
#add items:
x=('apple','orange','Lychee')
y=list(x)
y.append('orange')
x=tuple(y)
print(x)
#remove items:
x=('apple','orange','Lychee','RAymond')
y=list(x)
y.remove('RAymond')
x=tuple(y)
print(x)
#unpack a collection
fruits=('apple','orange','Lychee')
(red,orange,white)=fruits 
print(red)
print(orange)
print(white)
#loop tuples:
fruits=('apple','orange','Lychee')
for x in fruits:
    print(x)
for i in range(len(fruits)):
    print(fruits[i])
fruits=('apple','orange','Lychee')
i=0
while i < len(fruits):
    print(fruits[i])
    i=i+1
#join tuple
tuple1=(1,2,3,4)
tuple2=('a','b','c')
tuple3=tuple1+tuple2
print(tuple3)
print(tuple1+tuple2)
#multiplying tuples
tuple1=(1,2,3,4)
tuple2=tuple1 * 10
print(tuple2)
















print('\n')
print('\n')
print('\n')
print('\n')



#practice
x=('apple','orange','Raymond')
y=list(x)
y[2]='Lychee'
x=tuple(y)
print(x)


tuple1=('apple','orange','Lychee')
x=list(tuple1)
x.append('Dragon fruit')
tuple1=tuple(x)
print(tuple1)

tuple1=('apple','orange','Raymond')
x=list(tuple1)
x.remove('Raymond')
tuple1=tuple(x)
print(tuple1)

names=('bob','bobb','bobby')
(fname,fname2,fname3)=names
print(fname,fname2,fname3)

fruits=('apple','orange','Lychee')
for x in fruits:
    print(x)
    
fruits=('apple','orange','Lychee')
i=0
while i < (len(fruits)):
    print(fruits[i])























