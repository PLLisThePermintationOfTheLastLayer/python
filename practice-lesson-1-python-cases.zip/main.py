#camel:
firstName="Kyler"
#pascal:
MYAGE=3
#snake:
last_name=" Tsui"
#print
print(firstName,last_name,"\nage:",MYAGE,"\nType:")
print(type(firstName))
print(type(MYAGE))
