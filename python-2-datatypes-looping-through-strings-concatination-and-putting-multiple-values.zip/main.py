#multiple values min multiple variable
'''
x,y,z="1","2","3"
print(x,y,z)
'''
#Assigning same values
'''
i=j=k="hi"
print(i,j,k)
fruits=["Apple","orange","Peach"]
x,y,z=fruits
print(x,y,z)
'''
#output variables
'''
x="Python is better than c++"
print(x)
a="Python"
b="is better"
c="than"
trash="c++"
print(a,b,c,trash)
print(x)
'''
#concatitation
'''
a="Python "
b="is better "
c="than "
trash="c++"
print(a+b+c+trash)
name=7
name2=7
print(name+name2)
'''
#python datatypes
#int, float, complex= numeric type
#list, tuple, range= sequence type
#dictionaries= mapping type
#set= set datatypes
#bool = boolean type
'''
x="Python"
print(x)
print(type(x))
x=67
print(x)
print(type(x))
x=67.694206372
print(x)
print(type(x))
x=67j
print(x)
print(type(x))
x=-67.69420880808
print(x)
print(type(x))
x=6+7j
print(x)
print(type(x))
'''
#pyton casting
'''
x=int(1.11111)
print(x)
z=str(6)
print(z)
'''
#Python string:
'''
a="hello"
print(a)
'''
#string array
'''
a="python programming"
print(a[3])
print(a[17])
b="Python is a popular programming language created by"
print(b[47])
'''
#length and size of a string
s="Length"
print(len(s))
print("\n")
#looping through strings
for x in "programming":
     print(x)




























