myList=list(("apple","raymond"))
print(myList)
myList=["apple","orange","Raymond"]
print(myList[0:2])
myList=["apple","orange","Raymond"]
myList[2]="Brian"
print(myList)
myList=['apple', 'orange', 'Brian']
myList.append("Kyler")
print(myList)
myList=["apple","orange","brian"]
myList.insert(2,"Kyler")
print(myList)


