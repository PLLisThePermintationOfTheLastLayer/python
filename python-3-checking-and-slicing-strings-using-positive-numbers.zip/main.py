#checking string
text="The best things in life are free"
print("forest"in text)
if "best" in text:
    print("yes , it is here")
#slicing string
x="hello"
print(x)
print(x[0:5])
b="Astronaut"
print(b[5:9])